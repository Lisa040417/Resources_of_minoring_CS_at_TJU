#include <iostream>
#include <vector>

void computeNextArray(const char* pattern, int m, std::vector<int>& next) {
    next[0] = 0;
    int j = 0;

    for (int i = 1; i < m; i++) {
        while (j > 0 && pattern[i] != pattern[j]) {
            j = next[j - 1];
        }
        if (pattern[i] == pattern[j]) {
            j++;
        }
        next[i] = j;
    }
}

int KMPSearchCPP(const char* text, const char* pattern, int n, int m) {
    std::vector<int> next(m);
    computeNextArray(pattern, m, next);

    int j = 0;
    for (int i = 0; i < n; i++) {
        while (j > 0 && text[i] != pattern[j]) {
            j = next[j - 1];
        }
        if (text[i] == pattern[j]) {
            j++;
        }
        if (j == m) {
            return i - m + 1;
        }
    }
    return -1;
}
