#include <iostream>
#include <ctime>
#include <cstring>

extern "C" int KMPSearchASM(const char* text, const char* pattern, int n, int m);  // ���汾 KMP
int KMPSearchCPP(const char* text, const char* pattern, int n, int m);             // C++ �汾 KMP
void ShowResult(int result);

int main() {
    const char* text = "abxabcabcaby";
    const char* pattern = "abcaby";

    int n = strlen(text);
    int m = strlen(pattern);

    // C++ KMP
    clock_t begtime = clock();
    for (int i = 0; i < 10000; i++) {
        KMPSearchCPP(text, pattern, n, m);
    }
    clock_t endtime = clock();
    std::cout << "C++ KMP time: " << (float)(endtime - begtime) / CLOCKS_PER_SEC * 1000 << " ms" << std::endl;

    // ��� KMP
    begtime = clock();
    for (int i = 0; i < 10000; i++) {
        KMPSearchASM(text, pattern, n, m);
    }
    endtime = clock();
    std::cout << "ASM KMP time: " << (float)(endtime - begtime) / CLOCKS_PER_SEC * 1000 << " ms" << std::endl;

    ShowResult(KMPSearchASM(text, pattern, n, m));

    return 0;
}

void ShowResult(int result) {
    if (result != -1) {
        std::cout << "Pattern found at index: " << result << std::endl;
    }
    else {
        std::cout << "Pattern not found." << std::endl;
    }
}
