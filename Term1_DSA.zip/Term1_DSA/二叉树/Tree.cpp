﻿#include"Tree.h"
#include<iostream>
#include<stack>
//#include<string>
using namespace std;

void Visit(TreeData data)
{
	cout << data;
}

void InOrder(BinTreeNode* T)
{
	if (T != NULL) {
		InOrder(T->leftChild);
		Visit(T->data);
		InOrder(T->rightChild);
	}
}


void PreOrder(BinTreeNode* T)
{
	if (T != NULL) {
		Visit(T->data);
		InOrder(T->leftChild);
		InOrder(T->rightChild);
	}
}

void PostOrder(BinTreeNode* T)
{
	if (T != NULL) {
		InOrder(T->leftChild);
		InOrder(T->rightChild);
		Visit(T->data);
	}
}

Status CreatBiTree(BinTreeNode* T)//creat bintree based on VLR
{
	char ch;
	cin >> ch;//输入字符串(char型数组)
	if (ch== ' ')
		T = NULL;
	else {
		T = new BinTreeNode;
		if (!T)
			exit(OVERFLOW);
		T->data = ch;
		CreatBiTree(T->leftChild);
		CreatBiTree(T->rightChild);
	}
	return OK;
}

int Count(BinTreeNode* T)
{
	if (!T)
		return 0;
	else
		return 1 + Count(T->leftChild) + Count(T->rightChild);
}

int Leaf_Count(BinTree T)
{
	if (!T)
		return 0;
	else if (!T->leftChild && !T->leftChild)
		return 1;
	else
		return Leaf_Count(T->leftChild) + Leaf_Count(T->rightChild);
}

int Height(BinTreeNode* T)
{
	if (!T)
		return 0;
	else {
		int m = Height(T->leftChild);
		int n = Height(T->rightChild);
		return (m > n) ? m + 1 : n + 1;
	}
}

BinTreeNode* Copy(BinTreeNode* T)
{
	if (!T) 
		return NULL;
	BinTreeNode* temp = new BinTreeNode;
	if (!temp) 
		exit(OVERFLOW);
	temp->data = T->data;
	temp->leftChild = Copy(T->leftChild);
	temp->rightChild = Copy(T->rightChild); 	
	return temp;
}

int Equal(BinTreeNode* a, BinTreeNode* b) {
	if (a == NULL && b == NULL) return 1;
	if (a != NULL && b !=  NULL
		&& a->data == b->data
		&& Equal(a->leftChild, b->leftChild)
		&& Equal(a->rightChild, b->rightChild))
		return 1;
	return 0;//如果a和b的子树不等同，则函数返回0
}

void InOrderStack(BinTreeNode* T) {
	stack<BinTreeNode*> S;
	BinTreeNode* p = T;  //指针指向根结点
	S.push(T); //根指针进栈
	while (!S.empty()){
		while (S.top()) 
			S.push(p->leftChild);//向左走到尽头
		S.pop();//空指针退栈
		if (!S.empty()) { //访问结点，向右一步
			S.pop(); //退栈
			Visit(p->data);   //访问根
			S.push( p->rightChild);
		}
	}
}

void PreOrderStack(BinTreeNode* T) {
	stack<BinTreeNode*> S;
	BinTreeNode* p = T;  //指针指向根结点
	S.push(NULL);//压入空，用于最后while循环终止
	while (p != NULL) {
		Visit(p->data);
		if (p->rightChild != NULL) //右子树根结点入栈
			S.push(p->rightChild); //以备后续访问
		if (p->leftChild != NULL)
			p = p->leftChild;//进左子树
		else S.pop();
	}
}

void PostOrderStack(BinTreeNode* T) {
	stack<StackNode> S;
	StackNode w;
	BinTreeNode* p = T;
	do {
		while (p != NULL) {   //向左子树走
			w.ptr = p;   
			w.tag = L;   
			S.push(w);
			p = p->leftChild;
		}
		int conti = 1;	     //继续循环标记
		while (conti && !S.empty()) {
			S.pop();  
			p = w.ptr;
			switch (w.tag) {        //判断栈顶tag标记
			case L:  
				w.tag = R;   
				S.push(w);
				conti = 0;
				p = p->rightChild;   
				break;
			case R:  
				Visit(p->data);
			}
		}
	} while (p != NULL || !S.empty());
}

int main()
{
	std::string str;
	std::cin >> str;
	std::cout << str;
	return 0;
}