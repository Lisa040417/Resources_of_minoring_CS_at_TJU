#include<iostream>
#include<cassert>
#include <initializer_list>
#include"RBTree.h"
using namespace std;
//Define bidirectional iterator.
template<typename T>
struct node_iterator {
	typedef node_iterator<T> self;
	typedef Node<T> node;
	typedef T* pointer;
	typedef T& reference;
	//Define ptr, which point at RBTree's Node.
	node* ptr;
	//2 different construct functions.
	node_iterator(node* p) :ptr(p) {}
	node_iterator(const self& p) :ptr(p.ptr) {}
	//Overloaded operator
	bool operator == (const self& p)const {
		return ptr == p.ptr;
	}
	bool operator != (const self& p)const {
		return ptr != p.ptr;
	}
	self operator++() {
		//Begin at minimum value, if "right" isn't nullptr, make "ptr" point at
		//"right"'s leftmost.
		if (ptr->right != nullptr) {
			node* cur;
			cur = ptr->right;
			while (cur->left != nullptr) {
				cur = cur->left;
			}
			ptr = cur;
		}
		//If "right" is nullptr, also "ptr" is its "parent" right child, which means 
		// we've already traversed all right nodes, make "ptr" point at its "parent"
		// 's leftmost. If "right" is nullptr, but "ptr" is its  parent's left child, 
		// make "ptr" point at its parent.
		else {
			node* cur = ptr;
			node* up = ptr->parent;
			while (up != nullptr && up->right == cur) {
				cur = up;
				up = up->parent;
			}
			ptr = up;
		}
		return *this;
	}
	self operator--() {
		//Begin at maximum value, if "left" isn't nullptr, make "ptr" point at
		//"left"'s rightmost.
		if (ptr->left != nullptr) {
			node* cur;
			cur = ptr->left;
			while (cur->right != nullptr) {
				cur = cur->right;
			}
			ptr = cur;
		}
		//If "left" is nullptr, also "ptr" is its "parent" left child, which means 
		// we've already traversed all left nodes, make "ptr" point at its "parent"'s 
		// rightmost. If "left" is nullptr, but "ptr" is its  parent's right child, 
		// make "ptr" point at its parent.
		else {
			node* cur = ptr;
			node* up = ptr->parent;
			while (up != nullptr && up->left == cur) {
				cur = up;
				up = up->parent;
			}
			ptr = up;
		}
		return *this;
	}
	self operator++(int) {
		//Latch old iterator.
		self temp(*this);
		//Do calculation.
		++(*this);
		//Return old iterator.
		return temp;
	}
	self operator--(int) {
		//Latch old iterator.
		self temp(*this);
		//Do calculation.
		--(*this);
		//Return old iterator.
		return temp;
	}
	reference operator*()const {
		return ptr->data;
	}
	pointer operator->()const {
		return &(operator*());
	}
};
//Define const_iterator.
template<typename T>
struct node_const_iterator {
	typedef node_const_iterator<T> self;
	typedef Node<T> node;
	typedef const T* pointer;
	typedef const T& reference;
	//Define ptr, which point at RBTree's Node.
	node* ptr;
	//3 different types of construct functions.
	node_const_iterator(node* p) :ptr(p) {}
	node_const_iterator(const self& p) :ptr(p.ptr) {}
	node_const_iterator(const node_iterator<T>& p) :ptr(p.ptr) {}
	//Overloaded operator
	bool operator == (const self& p)const {
		return ptr == p.ptr;
	}
	bool operator != (const self& p)const {
		return ptr != p.ptr;
	}
	self operator++() {
		//Begin at minimum value, if "right" isn't nullptr, make "ptr" point at
		//"right"'s leftmost.
		if (ptr->right != nullptr) {
			node* cur;
			cur = ptr->right;
			while (cur->left != nullptr) {
				cur = cur->left;
			}
			ptr = cur;
		}
		//If "right" is nullptr, also "ptr" is its "parent" right child, which means 
		// we've already traversed all right nodes, make "ptr" point at its "parent"
		// 's leftmost. If "right" is nullptr, but "ptr" is its  parent's left child, 
		// make "ptr" point at its parent.
		else {
			node* cur = ptr;
			node* up = ptr->parent;
			while (up != nullptr && up->right == cur) {
				cur = up;
				up = up->parent;
			}
			ptr = up;
		}
		return *this;
	}
	self operator--() {
		//Begin at maximum value, if "left" isn't nullptr, make "ptr" point at
		//"left"'s rightmost.
		if (ptr->left != nullptr) {
			node* cur;
			cur = ptr->left;
			while (cur->right != nullptr) {
				cur = cur->right;
			}
			ptr = cur;
		}
		//If "left" is nullptr, also "ptr" is its "parent" left child, which means 
		// we've already traversed all left nodes, make "ptr" point at its "parent"'s 
		// rightmost. If "left" is nullptr, but "ptr" is its  parent's right child, 
		// make "ptr" point at its parent.
		else {
			node* cur = ptr;
			node* up = ptr->parent;
			while (up != nullptr && up->left == cur) {
				cur = up;
				up = up->parent;
			}
			ptr = up;
		}
		return *this;
	}
	self operator++(int) {
		//Latch old iterator.
		self temp(*this);
		//Do calculation.
		++(*this);
		//Return old iterator.
		return temp;
	}
	self operator--(int) {
		//Latch old iterator.
		self temp(*this);
		//Do calculation.
		--(*this);
		//Return old iterator.
		return temp;
	}
	reference operator*()const {
		return ptr->data;
	}
	pointer operator->()const {
		return &(operator*());
	}
};
//Class My_map
template<typename Key, typename Val>
class My_map {
public:
	typedef pair<Key, Val> T;
	typedef node_iterator<T> iterator;
	typedef node_const_iterator<T> const_iterator;
	typedef Node<T> node;
	typedef RBTree<T> RBTree;
private:
	size_t ele_num;
	RBTree map;
public:
	//Constructor.
	My_map() :
		ele_num(0) {}
	//Initializer constructor.
	My_map(initializer_list<T> i1) {
		for (const T& v : i1)
			insert(v);
	}
	//Copy constructor.
	My_map(const My_map<Key, Val>& other) :My_map() {
		const_iterator other_temp = other.cbegin();
		while (other_temp != other.cend()) {
			insert(*other_temp);
			++other_temp;
		}
	}
	//Move constructor, using copy assignment for map below.
	My_map(My_map&& other) :My_map() {
		map = other.map;
		other.clear();
	}
	//Deconstructor.
	~My_map() {
		clear();
		cout << "the map has been destroyed." << endl;
	}
	//Copy assignment
	My_map<Key, Val>& operator=(const My_map<Key, Val>& other) {
		if (this != &other) {
			clear();
			const_iterator other_temp = other.cbegin();
			while (other_temp != other.cend()) {
				insert(*other_temp);
				++other_temp;
			}
		}
		return *this;
	}
	//Move assignment.
	My_map<Key, Val>& operator=(My_map&& other) {
		clear();
		const_iterator other_temp = other.cbegin();
		while (other_temp != other.cend()) {
			insert(*other_temp);
			++other_temp;
		}
		other.clear();
		return *this;
	}
	//Access or insert specified element.
	Val& operator[](const Key& key) {
		pair<iterator, bool> result = insert({ key, Val() });
		return (*(result.first)).second;
	}
	//Head pointer and tail pointer of the map.
	iterator begin() {
		return map.minValueNode(map.getroot());
	}
	const_iterator begin() const {
		return map.minValueNode(map.getroot());
	}
	const_iterator cbegin() const {
		return map.minValueNode(map.getroot());
	}
	iterator end() {
		return iterator(nullptr);
	}
	const_iterator end() const {
		return const_iterator(nullptr);
	}
	const_iterator cend() const {
		return const_iterator(nullptr);
	}
	//Insert pairs in the map.
	pair<iterator, bool> insert(const T& data) {
		node* cur = map.getroot();
		node* parent = nullptr;
		//First, we need to find the location where to insert the value in
		//by comparing the key in data, inserting the pair in proper node
		//of Red-Black Tree.
		while (cur != nullptr) {
			parent = cur;
			if (data.first < cur->data.first) {
				cur = cur->left;
			}
			else if (data.first > cur->data.first) {
				cur = cur->right;
			}
			else {
				return make_pair(iterator(cur), false);
			}
		}
		//Second, establishing a newNode, which save the data input.
		node* newNode = new node(data);
		newNode->parent = parent;
		newNode->left = nullptr;
		newNode->right = nullptr;
		newNode->color = RED;
		//If parent is nullptr, that means that node is root.
		if (parent == nullptr) {
			map.setRoot(newNode);
		}
		else if (data.first < parent->data.first) {
			parent->left = newNode;
		}
		else {
			parent->right = newNode;
		}
		//Fix
		map.fixInsertRBTree(newNode);
		++ele_num;
		return make_pair(iterator(newNode), true);
	}
	//Clear all pairs in map.
	void clear() {
		//Set it start at begin, so that can we for-loop every pairs in map.
		iterator it = begin();
		//Just do it, until there's no element in the map.
		while (ele_num != 0) {
			node* nextNode = it.ptr->right ? it.ptr->right : it.ptr->parent;
			map.deleteValue(*it);
			it = iterator(nextNode);
			--ele_num;
		}
	}
	//Erasing the element which is paired with key input.
	void erase(const Key& key) {
		iterator it = find(key);
		if (it != end()) {
			map.deleteValue(*it);
			--ele_num;
		}
	}
	//Find the iterator, which points at key input.
	iterator find(const Key& key) {
		node* cur = map.getroot();
		//For-loop all map, finding where the iterator is.
		while (cur != nullptr) {
			if (key < cur->data.first) {
				cur = cur->left;
			}
			else if (key > cur->data.first) {
				cur = cur->right;
			}
			else {
				return iterator(cur);
			}
		}
		return iterator(nullptr);
	}
	//Return the map size.
	size_t size() const {
		return ele_num;
	}
	//Check if map is empty.
	bool empty() const {
		return ele_num;
	}
};