#include <iostream>
#include <string>
#include "My_map.h"
using namespace std;
int main() {
    //Initialize with a initializer_list.
    My_map<string, int> map1{ {"CPU", 10}, {"GPU", 15}, {"RAM", 20} };
    //Test for inserting some values.
    map1.insert(make_pair("lym", 4));
    map1.insert(make_pair("likes", 17));
    map1.insert(make_pair("lego", 66));
    //Test the nomal loop using iterator.
    cout << "For loop using const_iterator:" << endl;
    for (auto iter = map1.begin(); iter != map1.end(); iter++) {
        cout << "[" << iter->first << "]" << " \t\t " << iter->second << endl;
    }
    cout << "--------------------------------" << endl;
    //Test the for-each loop.
    cout << "For-each loop result:" << endl;
    for (auto& v : map1) {
        cout << "[" << v.first << "]" << "\t\t" << v.second << endl;
    }
    cout << "--------------------------------" << endl;
    //Test for modifying values in the map.
    cout << "Modify the value of the key 'lego':" << endl;
    map1["lego"] = 50;
    cout << "The after-modify value of 'lego' is: " << map1["lego"] << endl;
    cout << "--------------------------------" << endl;
    //Test erasing values in the map.
    cout << "Delete the value of the key 'CPU', 'GPU' and 'RAM'," << endl;
    cout << "output remaining values:" << endl;
    map1.erase("CPU");
    map1.erase("GPU");
    map1.erase("RAM");
    for (auto& v : map1) {
        cout << "[" << v.first << "]" << "\t\t" << v.second << endl;
    }
    cout << "--------------------------------" << endl;
    //Test copy constructor.
    My_map<string, int> map2(map1);
    cout << "Copy constructor map2 is:" << endl;
    for (auto& v : map2) {
        cout << "[" << v.first << "]" << "\t\t" << v.second << endl;
    }
    cout << "--------------------------------" << endl;
    //Test copy assignment.  
    My_map<string, int> map3;
    map3 = map2;
    cout << "Copy assignment map3 is:" << endl;
    for (auto& v : map3) {
        cout << "[" << v.first << "]" << "\t\t" << v.second << endl;
    }
    cout << "--------------------------------" << endl;
    //Test clearing a map.
    map1.clear();
    cout << "After clearing map1, else in map2:" << endl;
    for (auto& v : map2) {
        cout << "[" << v.first << "]" << "\t\t" << v.second << endl;
    }
    cout << "--------------------------------" << endl;
    //Test for finding.
    cout << "Find the value which is paired with 'likes':";
    cout << map3.find("likes")->second << endl;
    cout << "--------------------------------" << endl;
    //Test for size, before test, we insert 1 new value in map2.
    map2.insert(make_pair("Game", 70));
    cout << "The size of map2 is:";
    cout << map2.size() << endl;;
    cout << "--------------------------------" << endl;
    //Check whether the 3 maps are empty.
    cout << "map1:" << (map1.empty() ? "not empty" : "empty") << endl;
    cout << "map2:" << (map2.empty() ? "not empty" : "empty") << endl;
    cout << "map3:" << (map3.empty() ? "not empty" : "empty") << endl;
    cout << "--------------------------------" << endl;
    //Before exiting main function, the ~My_map<string, int> will be executed.
}