#include"Globals.h"
Configure* Configure::m_inst = NULL;
string Configure::m_fileName = "";

Configure::Configure() {
	ifstream reader(m_fileName.c_str(), ios::in);
	if (reader.is_open()) {
		//Read global variables from file 'config.txt'
		///////////////////////////////////////////////////
		// BEGIN OF YOUR CODE
		///////////////////////////////////////////////////
		string varName;
		while (reader >> varName) {
			if (varName == "MAP_WIDTH")
				reader >> m_mapWidth;
			else if (varName == "MAP_HEIGHT")
				reader >> m_mapHeight;
			else if (varName == "BLOCK_SIZE")
				reader >> m_blockSize;
			else if (varName == "NEXT_BLOCK_NUM")
				reader >> m_nextBlockNum;
			else if (varName == "MARGIN")
				reader >> m_margin;
			else if (varName == "RIGHT_WD_RATIO")
				reader >> m_rightWdRatio;
			else if (varName == "RIGHT_TXT_HT_RATIO")
				reader >> m_rightTxtHtRatio;
			else if (varName == "RIGHT_BLK_HT_RATIO")
				reader >> m_rightBlkHtRatio;
			else if (varName == "MAX_SCORE")
				reader >> m_maxScore;
		}
		///////////////////////////////////////////////////
		// END OF YOUR CODE
		///////////////////////////////////////////////////
	}
	else
		write();
	reader.close();
}
void Configure::write() {
	ofstream writter(m_fileName.c_str(), ios::out);
	writter << "MAP_WIDTH " << m_mapWidth << endl
		<< "MAP_HEIGHT " << m_mapHeight << endl
		<< "BLOCK_SIZE " << m_blockSize << endl
		<< "NEXT_BLOCK_NUM " << m_nextBlockNum << endl
		<< "MARGIN " << m_margin << endl
		<< "RIGHT_WD_RATIO " << m_rightWdRatio << endl
		<< "RIGHT_TXT_HT_RATIO " << m_rightTxtHtRatio << endl
		<< "RIGHT_BLK_HT_RATIO " << m_rightBlkHtRatio << endl
		<< "MAX_SCORE " << m_maxScore << endl;
	writter.close();
}